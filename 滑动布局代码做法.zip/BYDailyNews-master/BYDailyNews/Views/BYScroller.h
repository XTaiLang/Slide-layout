//
//  BYScroller.h
//  BYDailyNews
//
//  Created by bassamyan on 15/3/8.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BYScroller : UIScrollView

@end

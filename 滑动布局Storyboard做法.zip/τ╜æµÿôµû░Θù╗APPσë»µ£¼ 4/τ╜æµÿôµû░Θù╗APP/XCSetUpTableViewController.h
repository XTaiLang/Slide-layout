//
//  XCSetUpTableViewController.h
//  蓝汐学社
//
//  Created by xiaochao on 16/5/27.
//  Copyright © 2016年 筱超. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XCSetUpTableViewController : UITableViewController

@end

//
//  XCSetUpTableViewController.m
//  蓝汐学社
//
//  Created by xiaochao on 16/5/27.
//  Copyright © 2016年 筱超. All rights reserved.
//

#import "XCSetUpTableViewController.h"

@interface XCSetUpTableViewController ()
@property (weak, nonatomic) IBOutlet UILabel *RamLable;
@property (weak, nonatomic) IBOutlet UISwitch *mySwitch;
@property (weak, nonatomic) IBOutlet UISlider *mySlider;

@end

@implementation XCSetUpTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.backgroundColor=[UIColor orangeColor];
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    _RamLable.text=[NSString stringWithFormat:@"180M"];
}
- (IBAction)luminanceSlider:(UISlider *)sender {
    self.tableView.alpha=sender.value;
}

- (IBAction)nightSwitch:(UISwitch *)sender {
    if (_mySwitch.on==YES) {
        self.view.alpha=0.4;
    }
    else{
        self.view.alpha=1.0;
    }
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 4;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return 3;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    if (indexPath.section==0 && indexPath.row==1) {
        _RamLable.text=@"0M";
    }
}

@end

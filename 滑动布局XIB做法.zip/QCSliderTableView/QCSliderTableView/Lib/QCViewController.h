//
//  QCViewController.h
//  QCSliderTableView
//
//  Created by “ 邵鹏 on 14-4-16.
//  Copyright (c) 2014年 Scasy. All rights reserved.
//

#import "MMDrawerController.h"
#import "MMDrawerController+Subclass.h"
@interface QCViewController : MMDrawerController

@end
